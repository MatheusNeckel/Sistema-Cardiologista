
public class Medicao {

    private String data;
    private String hora;
    private Double pressaoSistolica;
    private Double pressaoDiastolica;

    public Medicao() {
    }

    public Medicao(String data, String hora, Double pressaoSistolica, Double pressaoDiastolica) {
        this.data = data;
        this.hora = hora;
        this.pressaoSistolica = pressaoSistolica;
        this.pressaoDiastolica = pressaoDiastolica;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public String getHora() {
        return hora;
    }

    public void setHora(String hora) {
        this.hora = hora;
    }

    public Double getPressaoSistolica() {
        return pressaoSistolica;
    }

    public void setPressaoSistolica(Double pressaoSistolica) {
        this.pressaoSistolica = pressaoSistolica;
    }

    public Double getPressaoDiastolica() {
        return pressaoDiastolica;
    }

    public void setPressaoDiastolica(Double pressaoDiastolica) {
        this.pressaoDiastolica = pressaoDiastolica;
    }

}
