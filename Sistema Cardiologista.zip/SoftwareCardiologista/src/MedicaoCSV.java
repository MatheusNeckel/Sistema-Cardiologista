
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;

public class MedicaoCSV {

    private static String nomeArquivo = "./Arquivo/medicao.csv";

    public static boolean adicionarMedicao(Medicao m) throws IOException {
        try {
            boolean arquivoExiste = new File(nomeArquivo).exists();

            FileWriter escritor = new FileWriter(nomeArquivo, StandardCharsets.ISO_8859_1, true);
            if (!arquivoExiste) {
                escritor.write("Data; Hora; Pressão Sistólica; Pressão Diastólica\n");
            }

            escritor.write(m.getData() + ";" + m.getHora() + ";" + m.getPressaoSistolica() + ";" + m.getPressaoDiastolica() + "\n");

            escritor.flush();
            escritor.close();
            return true;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
        }

    }
